const request = require('supertest')
const server = require('../server')

const db = require('../../data/dbConfig')

describe('server routes', () => {
    describe('GET /api/type', () => {

    })

    describe('POST /api/route', () => {

    })

    describe('GET /api/route/:id', () => {

    })
})
const route = require('express').Router()

route.get('/', (req, res) => {

})

module.exports = route